# Changelog

## 0.10.2 (2026-11-16)

Phones, tablets and PCs keep their own keyboards; kiosks are told apart from the keyboard.
- `useSharedScreen()`: a screen many people use in turn (a signup kiosk). True on the box's
  own touch screens, and in a venue client's touch (kiosk) mode, which sets
  `window.__BARGAMES_SHARED_SCREEN__ = true` and uses the device's system keyboard.
  `?bg_shared=1` (or `0`) for testing. Use it, not `useOnScreenKeyboard()`, to decide "forget
  the last person" (Stage Signup's kiosk).
- `<OnScreenKeyboard />`:
  - Enter no longer submits a form whose default submit button is disabled, as with a real
    keyboard.
  - It hides while someone types on a real keyboard (USB or Bluetooth), until the next field.
  - The open keyboard's height is on `<html>` as `--bargames-keyboard` (`KEYBOARD_VAR`), and
    the kit's bottom announcement strip sits above it.

## 0.10.1 (2026-11-16)

- `<OnScreenKeyboard />`: Enter in a `<textarea>` now sends a cancelable `keydown` Enter first, as
  for inputs; if the game calls `preventDefault()` (a one-line answer box that sends on Enter),
  no newline goes in. Otherwise it's a newline, as before.

## 0.10.0 (2026-11-16)

An on-screen keyboard for touchscreens that have none (box 0.21.0's touch screens).
- `<OnScreenKeyboard />` (client): mount it once near the root. It shows big keys under any
  focused text field, but only where no system keyboard comes up: a screen plugged into the
  box with Touch on (Chromium on Linux with a touchscreen), or a venue client that sets
  `window.__BARGAMES_KEYBOARD__ = true` (Android/desktop touch mode). Phones, tablets and PCs
  keep their own keyboard. Keys type like real ones: React's `onChange` fires, `maxLength`
  holds, Enter submits the form, numeric fields (`inputMode="numeric"`) get a number pad.
- `useOnScreenKeyboard()`: whether this screen gets it, for layouts that leave it room.
  `?bg_keyboard=1` (or `0`) on any page remembers a choice for testing.
- `wantsOnScreenKeyboard()`, `applyKey()`: the rules, for tests.

## 0.9.0 (2026-11-16)

Guest hosts (SDK 0.16.0, box 0.19.0) and bigger admin uploads.
- `staffOrGuest({ auth, guest, trusted?, cohosts? })`: a guard for the controls a guest may run
  (a karaoke queue, not its settings). Passes a signed-in admin, staff the box vouches for
  (`bg.isStaff`), or a guest from the box's guest link (`bg.guest`); a guest lands in
  `res.locals.guest`. Mount it on its own router: `adminRouter` routes stay staff-only.
  `cohosts: false` keeps co-hosts out.
- `adminRouter({ bodyLimit })`: the JSON limit (default "16kb"), for admin routes that take
  uploads (Trivia Night's question packs).

## 0.8.0 (2026-11-15)

Hosting from the box (SDK 0.14.0's standard commands host_link, cohost_link, remove_cohost).
- `HostSeats` (server), one per room, owns who may host:
  - `claimForJoiner()`: the box's "first joiner hosts" offer. `hostAttached(member)` closes it on
    ANY attach to the host seat, staff opening the host link included (the Bingo/BuzzBoard bug,
    where the next QR joiner got the same seat).
  - `takeover()`: a new host token; the old holder becomes a co-host (`previous`).
  - `invite(ttl)` / `redeem(token)`: single-use co-host invites, 10 minutes by default, 60 at most.
  - `addCohost`, `removeCohost`, `isCohost`, `cohosts`, `roleOf` ("host" | "cohost" | "player"),
    `canRun` (host or co-host).
- `wireBarGames(bg, rooms, { seats: { of, hostPath, cohostPath, onTakeover?, onCohostRemoved? } })`
  answers host_link / cohost_link / remove_cohost. Declare them in bargames.json "commands". The
  callbacks don't broadcast: send the room's new state yourself (Bingo 0.9.0's note).
- `JoinAddress` `maxWidth` (default "100%"; `null` leaves max-width to your CSS class, which an
  inline style used to beat).

## 0.7.4 (2026-11-14)

- `JoinAddress` / `JoinBox`, from the games' first round with it:
  - `minScale` (default 0.6): the smallest the address shrinks to. On a TV, 0.8 or 1 reads
    better, and the address wraps onto more lines instead.
  - `lines` (default 1): lines the box has room for before shrinking (2: full size up to 48
    characters). More lines make the box taller: check layouts with a height cap.
  - The CSS variable `--join-min-size` (e.g. `2.8vh`) sets an absolute floor, no `!important`.
  - `align: "start"` for a left-aligned address and label.
- Print the box's short room link when there is one: SDK 0.13.2
  `joinDisplay(ctx, path, code).roomShort` ("play.example.net/AB12", box 0.15.6) opens the room
  directly. Pass it as `url`.

## 0.7.3 (2026-11-14)

- `<JoinAddress url={ctx.game.publicUrl} />`: "Join at" plus the game's address under a QR
  code, for any venue address. It drops the scheme and trailing slash, breaks after every "."
  and "/" (`<wbr>`), shrinks long addresses (`max(0.6, min(1, 24 / length))` em) and breaks
  anywhere as a last resort, so it never runs out of its box. No layout opinions.
- `<JoinBox qr={…} code={…} url={…} />`: QR, address and code stacked; its width is
  `var(--join-max-width, 100%)` (or the `maxWidth` prop), so each layout sets its own.
  Background, padding and placement stay the game's.
- Helpers `shortAddress`, `addressParts`, `addressScale` (no SDK needed; SDK 0.13.1 has
  `joinDisplay(ctx, path)` → `{ url, short }` too).
- Lesson from Bingo 0.8.2: don't let the join box grow on long addresses; it squeezes the
  game's info column. Keep the width cap in the game's CSS.

## 0.7.2 (2026-11-12)

- `--bargames-announcement-top` too: a top strip's height (0px otherwise), for layouts that fill
  the viewport (`height: calc(100vh - var(--bargames-announcement-top, 0px) - var(--bargames-announcement-bottom, 0px))`).

## 0.7.1 (2026-11-12)

- A bottom `VenueAnnouncement` publishes its height as `--bargames-announcement-bottom` on
  `<html>` (0px when it's off, at the top, or hidden on this screen). Lift bottom-fixed bars
  with `bottom: var(--bargames-announcement-bottom, 0px)`; no ResizeObserver of your own.

## 0.7.0 (2026-11-12)

- `<BoxAdminLink ctx={venue} />`: "← Box admin" back to the venue box's admin, for your admin
  pages (box 0.12.0+ sends its address; renders nothing otherwise).
- `VenueAnnouncement` follows the announcement's `show` (everywhere / phones / tvs) and
  `position` (top / bottom) from box 0.12.0. To show TV announcements, render it on your TV
  view too: it hides itself where it doesn't belong.
- Venue updates arrive in seconds on box 0.12.0 (SDK 0.11.0's watchVenue holds the request).

## 0.6.2 (2026-11-12)

- `serveSpa` answers a missing file (anything under /assets/, or a path with a file
  extension) with 404 instead of the page, so a broken asset URL shows up as a 404.
- `basePathFromEnv` warns when BG_BASE_PATH/BASE_PATH is set but not a path (Git Bash turns
  "/bingo" into "C:/Program Files/Git/bingo"; use MSYS_NO_PATHCONV=1).

## 0.6.1 (2026-11-12)

- `serveSpa` / `injectBasePath` at the root (no prefix) add `<base href="/">` unless the page
  has its own, so a Vite `base: "./"` client works on reloaded deep links (`/room/ABCD`).

## 0.6.0 (2026-11-12)

A game can run under a path prefix (`https://venue.example.com/bingo/`), on a Bar Games box
(path routing, SDK 0.10.0) or behind your own reverse proxy. Unset, everything stays at the
root as before.
- Server: `serveSpa(app, { dist })` serves the built client and injects the prefix
  (`BG_BASE_PATH`, else `BASE_PATH`) into index.html as `<meta name="bargames-base">` and
  `<base href>`. `basePathFromEnv()`, `injectBasePath()`. The proxy strips the prefix, so
  your routes stay `/api`, `/socket.io`.
- Client: `serverBase(dev)` (origin + prefix, for fetch), `socketPath()` (socket.io's
  `path` option), `basePath()` (e.g. React Router's `basename`).
- Build the client with Vite `base: "./"`.

## 0.5.1 (2026-11-12)

On a Bar Games box the box's admin password takes over (pass `onBox: bg.connected` with
`venuePassword` to createAdminAuth). Off a box nothing changes.
- `/api/admin/status` adds `venueLogin` (show the sign-in form: the box's password works)
  and `setupAllowed` (false on a box unless the box vouches for staff).
- `/api/admin/setup` refuses on a box unless trusted, so a guest on the venue Wi-Fi can't
  claim the game by setting its password first.

## 0.5.0 (2026-11-12)

- `createAdminAuth({ venuePassword })`: on a Bar Games box the venue box's admin password
  also opens the game's admin, even before the game has its own. Pass
  `(pw, ip) => bg.checkVenuePassword(pw, ip)` (SDK 0.8.0). The box is only asked when the
  game's own password doesn't match, and limits guesses itself.

## 0.4.0 (2026-11-12)

Staff sign-in through the venue box (needs SDK 0.7.0 on the box side; works with SDK
0.4.0+ otherwise, it just never signs anyone in).
- Server: pass `trusted: (req) => bg.isStaff(req)` to `adminRouter`. Staff who open the
  game's settings from the box admin get a session without the game's password.
- Client: `staffSignIn(serverUrl)` on the admin page, before the password form: resolves a
  session token when the box vouches for this browser, else undefined.
- `createCall(...).withTimeout(ms)`: one call with a longer timeout (casting to TVs can take
  more than the default 8 s).

## 0.3.2 (2026-11-11)

From Bingo's adoption (non-breaking; still works with SDK 0.4.0, vendored with 0.5.0).
- `wireBarGames`: `claimMessages: { gone?, none? }` for the game's own words when a claim
  command is refused, and `endCause` (default `"admin"`) for rooms the box ends.
- `wireBarGames` only listens to the registry on a box (`bg.connected`).
- `notePlayers`: no `players_changed` when the count ends the window where it started (a
  join and a leave cancel out), and no timers when nothing listens.
- `useRoomConnection`: `call` is declared with method syntax, so a game's typed call
  function (narrower event names) fits without a cast.
- `SOCKET_OPTIONS` is typed `{ autoConnect: boolean; transports: string[] }`, so the
  README's `io(serverUrl, SOCKET_OPTIONS)` compiles.
- `<VenueAnnouncement />` hides itself on shared screens (SDK 0.5.0's `tableMode()` /
  `markSharedScreen()`), and its text uses `--venue-on-primary`.

## 0.3.1 (2026-11-11)

From No Filter's adoption (non-breaking).
- `<VenueAnnouncement hidden />`: hide the strip while the page is a shared/TV screen that
  only the room page can detect (a table that joined a plain room URL).

## 0.3.0 (2026-11-11)

Needs `@bargames/sdk` 0.4.0 (vendor `bargames-sdk-0.4.0.tgz` alongside it).
- Client: `<BackToGames ctx />` ("← All games" + "Also playing", landing page only) and
  `<VenueAnnouncement ctx />` (staff announcements). Both render nothing standalone.
- `useVenue` / `VenueBranding` poll the venue every 30 s (was 60 s) so announcements show
  up quickly.
- Rooms: `RoomRegistry({ joinPath: (r) => "/join/" + r.code })`, or a room's own
  `joinPath` property/method. Status carries it for venue and patron rooms, so the venue's
  games list shows a "Join" button; private rooms never get one.

## 0.2.2 (2026-11-11)

- `installShutdown` logs the stack trace of a crash, not just its message.
- Docs: use `io.close()` in `beforeExit` (httpServer.close() waits on open WebSockets).

## 0.2.1 (2026-11-11)

From No Filter's adoption (all non-breaking).
- Admin auth: new hashes are written in the configured `saltFormat` (adopting the kit stays
  reversible). README: per-IP lockout caution for standalone games behind Cloudflare.
- `KitRoom`: `phase`, `round`, `hostConnected`, `hostName`, `maxPlayers`, `pendingClaims`
  may be properties or methods; `overviewExtra()` overrides; `detail()` helper.
- `installShutdown`: `restartReason`, `crashReason` (rooms close with cause "error"),
  `drainMs` (default 400), `beforeExit`.
- `SOCKET_OPTIONS` / `SOCKET_SERVER_OPTIONS` also exported from `/server` (React-free).
- Client: `invalidatePublicConfig()` refetches every mounted public-config hook.
- `SERIAL_ALPHABET` comment corrected (31 characters).

## 0.2.0 (2026-11-11)

From No Filter's review (the oldest game; several of its versions were better). Breaking
changes are fine: no game had adopted 0.1.0.

**Fixes**
- Admin auth: `saltFormat` ("bytes" Bingo/Pool, "string" No Filter) so existing
  password files keep working; new hashes record their format.
- Admin auth: a damaged admin file fails closed (no setup land grab, no login, no
  throw) and is left untouched; `/login` and `/setup` errors no longer escape Express 4.

**Hardening**
- Global scrypt cap (2 concurrent, queue 8, then "busy") plus a capped escalating
  delay, alongside per-IP lockout. `login()` now returns `{ ok, token } | { ok:false, reason }`.
- Length-safe constant-time compare for `ADMIN_PASSWORD`. `adminConfigured()` and
  `broken()` alongside `setupNeeded()`.

**New**
- Store: `readResult` (missing / ok / invalid), validation, absolute paths, serialized `update`.
- `createSettingStore`, `createPresetStore` (with one-time migration).
- Rooms: `codeLength` / `codeAlphabet` / `normalizeCode` (default strips to A-Z0-9);
  `create(kind, init)` runs init before `room_created`; `ctx.close()` and `safeTimeout`
  for per-room crash containment; rooms whose idle check throws are dropped;
  `notePlayers` (debounced `players_changed`); `installShutdown`; `round()` in overviews;
  `close(reason, cause)`.
- `wireBarGames`: `players_changed`; commands get `ctx.actor = "venue"`; `end` takes a reason.
- Terms: `resolveTerms`, `normalizeTerm`, `fillTerms` (server and client).
- Client: `serverOrigin` override, `SOCKET_SERVER_OPTIONS`, `CallError` with `code`
  (string or `{code,message}` ack errors), `useRoomConnection` protocol options,
  `usePublicConfig` / `loadPublicConfig` (one cached fetch).

## 0.1.0 (2026-11-10)

First cut, extracted from Bingo and Pool (their copies were identical or nearly so).

- server: `createLogger`, `createJsonStore`, `createAdminAuth`, `adminRouter`, ids, `RoomRegistry`
  (cap, idle sweep that keeps venue rooms on a TV, close causes, events, `overviews()`
  with the Bar Games Rooms-page fields).
- bargames: `wireBarGames(bg, rooms, { createVenueRoom, commands, claims })`.
- client: `createSessionStore`, `serverOrigin`, `SOCKET_OPTIONS`, `createCall`,
  `useRoomConnection`, `ErrorBoundary`, `useVenue`, `VenueBranding`, `useGameName`.
- Built against `@bargames/sdk` 0.3.0.
